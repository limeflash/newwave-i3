# Contributing to betterlockscreen

Thanks for taking your time to contribute!

First off, any and all contributions are welcome.

Secondly, if your pull request or issue is in any way related to the [AUR package](https://aur.archlinux.org/packages/betterlockscreen-git/), 
for example if your pull request adds a new dependency, 
please notify the maintainer @AUTplayed via a mention (like used here with the @) in your comment.

Thanks
