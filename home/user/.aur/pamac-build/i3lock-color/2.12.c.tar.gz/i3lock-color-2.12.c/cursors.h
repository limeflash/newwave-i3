#ifndef _CURSORS_H
#define _CURSORS_H

#define CURS_NONE 0
#define CURS_WIN 1
#define CURS_DEFAULT 2

#endif
