List for i3lock-color
===============================
* Make alpha a bit less hacky / play better with other colors
* Let the user specify 3 colors and have it generate shades based off them
* Rainbow mode / random color mode?
* Maybe add a bar unlock indicator instead of a ring?
